package ru.practikum.model;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

}