package ru.practikum.manager;

import org.junit.jupiter.api.Test;
import ru.practikum.model.Status;
import ru.practikum.model.Task;

import static org.junit.jupiter.api.Assertions.*;

class HistoryManagerTest {
    @Test
    void shouldPreserveOriginalTaskState() {
        HistoryManager history = Managers.getDefaultHistory();

        // Создаем задачу
        Task original = new Task("Тестовая задача", "Описание", Status.NEW);
        original.setId(1);

        // Добавляем в историю
        history.add(original);

        // Меняем оригинал
        original.setStatus(Status.DONE);
        original.setName("Измененная задача");

        // Проверяем задачу в истории
        Task historical = history.getHistory().get(0);

        assertEquals(Status.NEW, historical.getStatus(), "Статус должен остаться NEW");
        assertEquals("Тестовая задача", historical.getName(), "Название должно остаться оригинальным");
    }

    @Test
    void shouldLimitHistorySize() {
        HistoryManager history = Managers.getDefaultHistory();

        // Добавляем 15 задач
        for (int i = 1; i <= 15; i++) {
            Task task = new Task("Задача " + i, "Описание", Status.NEW);
            task.setId(i);
            history.add(task);
        }

        // Проверяем размер истории
        assertEquals(10, history.getHistory().size(), "История должна содержать 10 элементов");

        // Проверяем, что остались последние 10 задач
        assertEquals(6, history.getHistory().get(0).getId(), "Первый элемент должен быть 6");
        assertEquals(15, history.getHistory().get(9).getId(), "Последний элемент должен быть 15");
    }
}