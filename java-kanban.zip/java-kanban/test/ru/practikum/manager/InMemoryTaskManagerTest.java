package ru.practikum.manager;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.practikum.model.*;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryTaskManagerTest {
    private TaskManager manager;

    @BeforeEach
    void setUp() {
        manager = Managers.getDefault();
    }

    @Test
    void shouldAddAndFindDifferentTaskTypes() {
        int taskId = manager.createTask(new Task("Task", "Description", Status.NEW));
        int epicId = manager.createEpic(new Epic("Epic", "Description"));
        int subtaskId = manager.createSubtask(new Subtask("Subtask", "Description", Status.NEW, epicId));

        assertNotNull(manager.getTaskById(taskId));
        assertNotNull(manager.getEpicById(epicId));
        assertNotNull(manager.getSubtaskById(subtaskId));

        assertEquals(1, manager.getAllTasks().size());
        assertEquals(1, manager.getAllEpics().size());
        assertEquals(1, manager.getAllSubtasks().size());
    }

    @Test
    void taskShouldRemainUnchangedAfterAdding() {
        Task original = new Task("Original", "Description", Status.NEW);
        original.setId(1);

        manager.createTask(original);
        Task saved = manager.getTaskById(1);

        assertEquals(original.getId(), saved.getId());
        assertEquals(original.getName(), saved.getName());
        assertEquals(original.getDescription(), saved.getDescription());
        assertEquals(original.getStatus(), saved.getStatus());
    }
}