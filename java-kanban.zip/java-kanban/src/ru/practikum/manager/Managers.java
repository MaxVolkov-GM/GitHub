package ru.practikum.manager;

public class Managers {
    private Managers() {} // Запрещаем создание экземпляров

    public static TaskManager getDefault() {
        return new InMemoryTaskManager();
    }

    public static HistoryManager getDefaultHistory() {
        return new InMemoryHistoryManager();
    }
}