package ru.practikum.manager;

import ru.practikum.model.Epic;
import ru.practikum.model.Subtask;
import ru.practikum.model.Task;

import java.util.LinkedList;
import java.util.List;

public class InMemoryHistoryManager implements HistoryManager {
    private final LinkedList<Task> history = new LinkedList<>();
    private static final int MAX_HISTORY_SIZE = 10;

    @Override
    public void add(Task task) {
        if (task == null) return;

        // Создаем копию задачи для истории
        Task copy = copyTask(task);
        history.addLast(copy);

        // Удаляем старые записи, если превышен лимит
        if (history.size() > MAX_HISTORY_SIZE) {
            history.removeFirst();
        }
    }

    // Создаем копию задачи правильного типа
    private Task copyTask(Task original) {
        if (original instanceof Epic) {
            return new Epic((Epic) original);
        } else if (original instanceof Subtask) {
            return new Subtask((Subtask) original);
        } else {
            return new Task(original);
        }
    }

    @Override
    public List<Task> getHistory() {
        return new LinkedList<>(history);
    }
}